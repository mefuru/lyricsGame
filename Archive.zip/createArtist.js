var artist = require("./modules/artist"), cheerio = require('cheerio')
request = require("request");

console.log(process.argv);

console.log(typeof artist);
var tupac = new artist(process.argv[2]);
tupac.print_name();
console.log(tupac.name);
var baseURL = "http://rapgenius.com/artists/";
var URL = "";
request(baseURL+tupac.name, function (error, response, body) {
    if (!error && response.statusCode == 200) {
	var $ = cheerio.load(body);
	URL = $("[property='og:url']").attr('content');
	tupac.add_link(URL);
	tupac.print_link();
	var nameFromURL = $("[property='og:title']").attr('content');
	tupac.update_name(nameFromURL);
	tupac.print_name();
    }
});


